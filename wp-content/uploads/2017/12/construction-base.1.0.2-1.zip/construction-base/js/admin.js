( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#construction-base-settings-metabox-container' ).tabs();

	});

} )( jQuery );
